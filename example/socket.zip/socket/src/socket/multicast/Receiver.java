package socket.multicast;
import sun.net.*;
import java.net.*;

public class Receiver {
	
	

}
